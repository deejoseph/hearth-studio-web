<?php
require_once(__DIR__ . "/admin_auth.php");
require_once(__DIR__ . "/config/db.php");

function compressImage($source, $destination, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') {
        $image = imagecreatefromjpeg($source);
        imagejpeg($image, $destination, $quality);
    }
    elseif ($info['mime'] == 'image/png') {
        $image = imagecreatefrompng($source);
        imagepng($image, $destination, 8);
    }
}

function compressTo200KB($source, $destination) {

    $info = getimagesize($source);
    if (!$info) return false;

    $mime = $info['mime'];

    if ($mime == 'image/jpeg') {
        $image = imagecreatefromjpeg($source);
    } elseif ($mime == 'image/png') {
        $image = imagecreatefrompng($source);
    } else {
        return false;
    }

    $width = imagesx($image);
    $height = imagesy($image);

    // 最大宽度限制
    $maxWidth = 1600;
    if ($width > $maxWidth) {
        $newHeight = intval($height * ($maxWidth / $width));
        $resized = imagecreatetruecolor($maxWidth, $newHeight);
        imagecopyresampled($resized, $image, 0, 0, 0, 0, $maxWidth, $newHeight, $width, $height);
        $image = $resized;
    }

    $quality = 85;

    do {
        imagejpeg($image, $destination, $quality);
        $filesize = filesize($destination);
        $quality -= 5;
    } while ($filesize > 200000 && $quality > 30);

    imagedestroy($image);

    return true;
}

function createThumbnail($source, $destination, $newWidth) {

    list($width, $height) = getimagesize($source);

    $ratio = $height / $width;
    $newHeight = $newWidth * $ratio;

    $thumb = imagecreatetruecolor($newWidth, $newHeight);

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') {
        $sourceImage = imagecreatefromjpeg($source);
    } elseif ($info['mime'] == 'image/png') {
        $sourceImage = imagecreatefrompng($source);
    } else {
        return;
    }

    imagecopyresampled(
        $thumb,
        $sourceImage,
        0, 0, 0, 0,
        $newWidth, $newHeight,
        $width, $height
    );

    imagejpeg($thumb, $destination, 85);
}

if ($_SESSION['admin_role'] !== 'super_admin') {
    header("Location: studio_dashboard.php");
    exit;
}

$base_url = "https://www.ichessgeek.com/HearthStudio";
$order_id = intval($_GET['order_id'] ?? 0);
$message = "";

/* =====================================================
   1️⃣ 推进阶段
===================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['move_stage'])) {

    $move_order_id = intval($_POST['order_id']);
    $conn->begin_transaction();

    try {

        $stmt = $conn->prepare("SELECT status_id FROM orders WHERE id = ? FOR UPDATE");
        $stmt->bind_param("i", $move_order_id);
        $stmt->execute();
        $orderRow = $stmt->get_result()->fetch_assoc();

        if (!$orderRow) throw new Exception("Order not found");

        $current_status_id = intval($orderRow['status_id']);

        $stmt = $conn->prepare("SELECT sort_order, label FROM order_status WHERE id = ?");
        $stmt->bind_param("i", $current_status_id);
        $stmt->execute();
        $current_status = $stmt->get_result()->fetch_assoc();

        if (!$current_status) throw new Exception("Current status missing");

        $stmt = $conn->prepare("
            SELECT id, label 
            FROM order_status 
            WHERE sort_order > ?
            ORDER BY sort_order ASC
            LIMIT 1
        ");
        $stmt->bind_param("i", $current_status['sort_order']);
        $stmt->execute();
        $next_status = $stmt->get_result()->fetch_assoc();

        if (!$next_status) throw new Exception("Already final stage");

        $next_status_id = intval($next_status['id']);

        $stmt = $conn->prepare("UPDATE orders SET status_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $next_status_id, $move_order_id);
        $stmt->execute();

        $note = "Moved from {$current_status['label']} to {$next_status['label']}";
        $changed_by = $_SESSION['admin_username'];

        $stmt = $conn->prepare("
            INSERT INTO order_status_logs
            (order_id, from_status_id, to_status_id, changed_by, note, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("iiiss",
            $move_order_id,
            $current_status_id,
            $next_status_id,
            $changed_by,
            $note
        );
        $stmt->execute();

        $conn->commit();
        header("Location: admin_order.php?order_id=" . $move_order_id);
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $message = $e->getMessage();
    }
}

/* =====================================================
   2️⃣ 回复客户消息
===================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reply'])) {

    $reply_order_id = intval($_POST['order_id']);
    $reply = trim($_POST['studio_reply']);

    if ($reply) {

        // 当前状态
        $stmt = $conn->prepare("SELECT status_id FROM orders WHERE id = ?");
        $stmt->bind_param("i", $reply_order_id);
        $stmt->execute();
        $orderRow = $stmt->get_result()->fetch_assoc();
        $status_id = $orderRow ? intval($orderRow['status_id']) : null;

        // 查是否有未关闭的客户消息
        $stmt = $conn->prepare("
            SELECT id 
            FROM order_progress_messages
            WHERE order_id = ?
            AND is_closed = 0
            ORDER BY created_at DESC
            LIMIT 1
        ");
        $stmt->bind_param("i", $reply_order_id);
        $stmt->execute();
        $openRow = $stmt->get_result()->fetch_assoc();

        if ($openRow) {

            // 更新这条记录
            $stmt = $conn->prepare("
                UPDATE order_progress_messages
                SET studio_reply = ?,
                    studio_reply_at = NOW(),
                    status_id = ?,
                    is_closed = 1
                WHERE id = ?
            ");
            $stmt->bind_param("sii", $reply, $status_id, $openRow['id']);
            $stmt->execute();

        } else {

            // 没有未关闭记录 → 新建一条
            $stmt = $conn->prepare("
                INSERT INTO order_progress_messages
                (order_id, studio_reply, studio_reply_at, status_id, is_closed, created_at)
                VALUES (?, ?, NOW(), ?, 1, NOW())
            ");
            $stmt->bind_param("isi", $reply_order_id, $reply, $status_id);
            $stmt->execute();
        }
    }

    header("Location: admin_order.php?order_id=" . $reply_order_id);
    exit;
}
/* =====================================================
   3️⃣ 发送进度图片
===================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_image'])) {

    $upload_order_id = intval($_POST['order_id']);

    if (!empty($_FILES['studio_image']['name'])) {

        // 获取订单信息
        $stmt = $conn->prepare("SELECT order_number, status_id FROM orders WHERE id = ?");
        $stmt->bind_param("i", $upload_order_id);
        $stmt->execute();
        $orderRow = $stmt->get_result()->fetch_assoc();

        if (!$orderRow) die("Order not found");

        $order_number = $orderRow['order_number'];
        $status_id = intval($orderRow['status_id']);
        $year = date("Y");

        // 目录
        $upload_dir = $_SERVER['DOCUMENT_ROOT'] . "/HearthStudio/Customize/{$year}/{$order_number}/";

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $original_name = basename($_FILES['studio_image']['name']);
        $filename = time() . "_" . $original_name;
        $target_path = $upload_dir . $filename;

        // 压缩并保存
        if (compressTo200KB($_FILES['studio_image']['tmp_name'], $target_path)) {

            $db_path = "/HearthStudio/Customize/{$year}/{$order_number}/" . $filename;

            $stmt = $conn->prepare("
                INSERT INTO order_progress_images
                (order_id, studio_image, status_id, created_at)
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->bind_param("isi", $upload_order_id, $db_path, $status_id);
            $stmt->execute();
        }
    }

    header("Location: admin_order.php?order_id=" . $upload_order_id);
    exit;
}

/* =====================================================
   4️⃣ 获取订单信息
===================================================== */
$order = null;
$messages = null;
$images = null;
$next_status = null;

if ($order_id) {

    $stmt = $conn->prepare("
        SELECT o.*, s.label, s.sort_order
        FROM orders o
        JOIN order_status s ON o.status_id = s.id
        WHERE o.id = ?
    ");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();

    if ($order) {

        $stmt = $conn->prepare("
            SELECT id, label
            FROM order_status
            WHERE sort_order > ?
            ORDER BY sort_order ASC
            LIMIT 1
        ");
        $stmt->bind_param("i", $order['sort_order']);
        $stmt->execute();
        $next_status = $stmt->get_result()->fetch_assoc();

        $messages = $conn->query("
            SELECT *
            FROM order_progress_messages
            WHERE order_id = {$order_id}
            ORDER BY created_at ASC
        ");

        $images = $conn->query("
            SELECT *
            FROM order_progress_images
            WHERE order_id = {$order_id}
            ORDER BY created_at ASC
        ");
    }
}

require_once(__DIR__ . "/admin_layout.php");
?>

<h1>Super Admin – Order Management</h1>

<div class="card">

<h2>Search Order</h2>
<form method="GET">
    <input type="number" name="order_id" placeholder="Enter Order ID" required>
    <button type="submit">Load</button>
</form>

<?php if ($order): ?>

<hr>
<h2>Order #<?php echo $order['order_number']; ?></h2>
<p><strong>Status:</strong> <?php echo $order['label']; ?></p>

<?php if ($next_status): ?>
<form method="POST">
    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
    <button name="move_stage">Move to Next Stage</button>
</form>
<?php endif; ?>

<hr>
<h3>Messages</h3>

<?php while ($row = $messages->fetch_assoc()): ?>

    <?php if ($row['customer_message']): ?>
        <div class="message customer">
            <strong>Customer:</strong>
            <?php echo htmlspecialchars($row['customer_message']); ?>
        </div>
    <?php endif; ?>

    <?php if ($row['studio_reply']): ?>
        <div class="message studio">
            <strong>Studio:</strong>
            <?php echo htmlspecialchars($row['studio_reply']); ?>
        </div>
    <?php endif; ?>

<?php endwhile; ?>

<form method="POST">
    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
    <textarea name="studio_reply" placeholder="Reply to customer..." required></textarea>
    <button name="send_reply">Send Reply</button>
</form>

<hr>
<h3>Progress Images</h3>

<div style="display:flex; flex-wrap:wrap; gap:15px;">

<?php while ($img = $images->fetch_assoc()): ?>

    <a href="<?php echo htmlspecialchars($img['studio_image']); ?>" target="_blank">
        <img src="<?php echo htmlspecialchars($img['studio_image']); ?>" 
             style="width:240px; height:auto; border-radius:8px; cursor:pointer;">
    </a>

<?php endwhile; ?>

</div>

<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
    <input type="file" name="studio_image" required>
    <button name="upload_image">Upload Image</button>
</form>

<?php endif; ?>

</div>

<?php require_once(__DIR__ . "/admin_footer.php"); ?>